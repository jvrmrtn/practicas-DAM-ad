import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hfkra
 */
public class apartado02A {

    /* Visualizar todas las etiquetas del fichero 
    LIBROS.XML utilizando las técnicas DOM y SAX.*/
    
    public static void main(String[] args) throws IOException, SAXException {

        try {
            
            //CREAMOS EL OBJETO DOCUMENTO Y LEEMOS EL ARCHIVO libros.xml
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document documento = dBuilder.parse("libros.xml");           
            
            //MOSTRAMOS EL ELEMENTO RAIZ
            System.out.println("");
            System.out.println("Archivo raiz: " + documento.getDocumentElement().getNodeName() + ".");
            System.out.println("");
            
            //INSTANCIAMOS UNA LISTA DE ELMENTOS "LIBRO"
            NodeList nList = documento.getElementsByTagName("libro");

            //RECORREMOS ESA LISTA IMPRIMIENTO LA ETIQUETA "LIBRO"
            for (int i = 0; i < nList.getLength(); i++) {
                Node nodo = nList.item(i);
                System.out.println("-----------------------------------------");
                System.out.println(nodo.getNodeName() + " " + (i + 1));
                System.out.println("-----------------------------------------");

                //RECOGEMOS LOS NODOS TIPO ELEMENTO
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) nodo;
                    System.out.println("año: " + element.getAttribute("año") + ".");

                    //INSTANCIAMOS LA LISTA DE ELEMENTOS
                    NodeList hijos = element.getChildNodes();
                    
                    //RECORREMOS LOS NODOS Y LOS IMPRIMIMOS POR CONSOLA
                    for (int j = 0; j < hijos.getLength(); j++) {
                        Node hijo = hijos.item(j);
                        if (hijo.getNodeType() == Node.ELEMENT_NODE) {
                            if (!"autor".equals(hijo.getNodeName())) {
                                System.out.print(hijo.getNodeName() + ": ");
                                System.out.println(hijo.getTextContent() + ".");
                            } else {
                                System.out.print("autor:");
                                
                                //INSTANCIAMOS LA LISTA DE ELEMENTOS "AUTOR"
                                NodeList node = hijo.getChildNodes();
                                
                                //RECORREMOS E IMPRIMIMOS NOMBRE Y APELLIDO POR CONSOLA.
                                for (int k = 0; k < node.getLength(); k++) {
                                    Node autor = node.item(k);
                                    if (autor.getNodeType() == Node.ELEMENT_NODE) {
                                        System.out.print(" " + autor.getTextContent());
                                    }
                                }
                                System.out.print(".");
                                System.out.println("");
                            }
                        }
                    }
                }
                System.out.println("");
            }
            System.out.println("");
            System.out.println("Fin del archivo.");
            System.out.println("");
            
        } catch (ParserConfigurationException ex) {
            ex.getMessage();
        }
    }
}

