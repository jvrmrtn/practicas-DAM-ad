
import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hfkra
 */
public class Handler extends DefaultHandler {
    
    //INSTANCIO LAS VARIABLES
    StringBuilder buffer = new StringBuilder();
    String apellido, nombre;

    //METODO LEER CARACTERES
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        buffer.append(ch, start, length);
    }

    //METODO FIN ELEMENTO
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        switch (qName) {
            case "titulo":
                System.out.println("Titulo: " + buffer.toString().trim());//Corregir espacio delante del ultimo titulo.
                break;
            case "apellido":
                apellido = String.valueOf(buffer);
                break;
            case "nombre":
                nombre = String.valueOf(buffer);
                break;
            case "autor":
                System.out.println(nombre + " " + apellido);
                break;
            case "editorial":
                System.out.println("Editorial: " + buffer);
                break;
            case "precio":
                System.out.println("Precio: " + buffer + "€");
                break;
            case "libro":
                System.out.println("");
                break;
        }
    }

    //METODO EMPIEZA ELEMENTO
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

        switch (qName) {
            case "bib":
                System.out.println("Archivo raíz: bib.");
                System.out.println("");
            case "libro":
                System.out.println("Libro");
                System.out.println("Año: " + attributes.getValue(0));
                break;

            case "titulo":
            case "apellido":
            case "nombre":
            case "editorial":
            case "precio":
                buffer.delete(0, buffer.length());
                break;

            case "autor":
                System.out.print("Autor: ");
                break;
        }
    }

}
