
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hfkra
 */
public class apartado01B {
    
    /*A partir de los datos del fichero EMPLEADOS.DAT
    crear un fichero llamado EMPLEADOS.XML usando DOM*/

    public static void main(String[] args) throws IOException{
        
        try {
            
            //RECUPERAR ARCHIVO CON DATOS ACCESO ALEATORIO
            RandomAccessFile raf = new RandomAccessFile("EMPLEADOS.dat", "r");
            
            //INSTANCIAR DOCUMENTO DOM EN MEMORIA
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            DOMImplementation implementation = builder.getDOMImplementation();
            
            //ELEMENTO DOCUMENTO
            Document documento = implementation.createDocument(null, "EMPLEADOS", null);
            documento.setXmlVersion("1.0");
            
            //ELEMENTO RAIZ
            Element empleados = documento.createElement("EMPLEADOS");
            
            //BUCLE LEER DATOS EMPLEADOS.dat Y CONSTRUIR ETIQUETA EMPLEADO
            for(int i=0; i < raf.length(); i+=64){ //Cada registro son 64 bytes.
                
                //CREAR ELEMENTO EMPLEADO
                Element empleado = documento.createElement("empleado");
                
                //POSICIONAR CURSOR AL PRINCIPIO DEL ARCHIVO EMPLEADOS.dat
                raf.seek(i);
                
                //LEER DATOS EMPLEADOS.dat
                int cod = raf.readInt();
                String cadenaCodigo = String.valueOf(cod);
   
                String cadenaNombre = "";
                for(int n = 0; n<10;n++){
                    char c = raf.readChar();
                    cadenaNombre += String.valueOf(c);
                }
                cadenaNombre = cadenaNombre.trim();
                
                String cadenaDireccion = "";
                for (int d = 0; d < 16; d++) {
                    char da = raf.readChar();
                    cadenaDireccion += String.valueOf(da);
                }
                cadenaDireccion = cadenaDireccion.trim();
                
                float sue = raf.readFloat();
                String cadenaSueldo = String.valueOf(sue);
                if(cadenaSueldo.length() <= 6){
                    cadenaSueldo += "0€";
                }else{
                    cadenaSueldo += "€";
                }
                cadenaSueldo = cadenaSueldo.replace(".",",");
                
                float com = raf.readFloat();
                String cadenaComision = String.valueOf(com);
                if(cadenaComision.length() <= 5){
                    cadenaComision += "0€";
                }else{
                    cadenaComision += "€";
                }
                cadenaComision = cadenaComision.replace(".",",");
                              
                //CREAR ELEMENTO CODIGO
                Element codigo = documento.createElement("código");
                Text textCodigo = documento.createTextNode(cadenaCodigo);
                codigo.appendChild(textCodigo);
                empleado.appendChild(codigo);  
                
                //CREAR ELEMENTO NOMBRE
                Element nombre = documento.createElement("nombre");
                Text textNombre = documento.createTextNode(cadenaNombre);
                nombre.appendChild(textNombre);
                empleado.appendChild(nombre);
                
                //CREAR ELEMENTO DIRECCION
                Element direccion = documento.createElement("dirección");
                Text textDireccion = documento.createTextNode(cadenaDireccion);
                direccion.appendChild(textDireccion);
                empleado.appendChild(direccion);
                
                //ELEMENTO SUELDO
                Element sueldo = documento.createElement("sueldo");
                Text textSueldo = documento.createTextNode(cadenaSueldo);
                sueldo.appendChild(textSueldo);
                empleado.appendChild(sueldo);
                
                //ELEMENTO COMISION
                Element comision = documento.createElement("comisión");
                Text textComision = documento.createTextNode(cadenaComision);
                comision.appendChild(textComision);
                empleado.appendChild(comision);

                //ESCRIBIR CADA ETIQUETA EMPLEADO EN ELEMENTO RAIZ
                empleados.appendChild(empleado);
                }
            
            //ELEMENTO RAIZ DENTRO DEL DOCUMENTO
            documento.getDocumentElement().appendChild(empleados);
            
            //CREACION DE ADAPTADORES SOURCE Y RESULT A PARTIR DE DOCUMENTO
            Source source = new DOMSource(documento);
            Result result = new StreamResult(new File("EMPLEADOS.xml"));
            
            //CREACION E INSTALACION TRANSFORMER
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(source, result);
            
        } catch (ParserConfigurationException | TransformerException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
