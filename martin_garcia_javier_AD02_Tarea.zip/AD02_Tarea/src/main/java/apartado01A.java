
import java.io.IOException;
import java.io.RandomAccessFile;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hfkra
 */
public class apartado01A {
    
    /*Crear un fichero EMPLEADOS.DAT de acceso aleatorio, 
    que contenga al menos cinco empleados. Dicho fichero 
    contendrá los campos siguientes: CODIGO (int), NOMBRE (string), 
    DIRECCION (string), SALARIO (float) y COMISION (float).*/
    
    public static void main(String[] args) throws IOException{
        
        //DECLARAR VARIABLES
        int codigo[] = {1,2,3,4,5};
        String[] nombre = {"Juan", "Silvia", "Andres", "Sonia", "Estela"};
        String[] direccion = {"Calle Clavel", "Calle Amapola", "Calle Lirio", "Calle Tulipan", "Calle Margarita"};
        float[] sueldo = {1000.01f,1125.50f,1200.10f,1501.37f,2115.75f};
        float[] comision = {110.57f,160.35f,190.15f,350.50f,400.00f};
        
        //CREAR ARCHIVO
        RandomAccessFile raf = new RandomAccessFile("EMPLEADOS.dat", "rw");
        
        //BUCLE RELLENAR ARCHIVO CON DATOS DE VARIABLES
        for(int i = 0; i<codigo.length; i++){
            raf.writeInt(codigo[i]);
            StringBuffer sb = new StringBuffer(nombre[i]);
            sb.setLength(10);
            raf.writeChars(sb.toString());
            StringBuffer sb2 = new StringBuffer(direccion[i]);
            sb2.setLength(16);
            raf.writeChars(sb2.toString());
            raf.writeFloat(sueldo[i]);
            raf.writeFloat(comision[i]);
            //CADA REGISTRO OCUPA 64bytes --> 0,64,128,192,256. raf.seek(0);
        }       
    }    
}
