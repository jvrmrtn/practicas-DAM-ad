
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hfkra
 */
public class Apartado2 {
        
        //Mostrar la información de la tabla pasajeros.
    
    public static void main(String[] args){
        
        try {           
            String urljdbc = "jdbc:oracle:thin:@localhost:1521:XE";
            Connection con = DriverManager.getConnection(urljdbc, "c##javier", "javier");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM PASAJEROS");
            while(rs.next()){
                System.out.println("---------------------------");
                System.out.println("Pasajero nº: "+rs.getInt(1)
                    +"\nCodigo de vuelo: "+rs.getString(2)
                    +"\nTipo de plaza: "+rs.getString(3)
                    +"\nFumador: "+rs.getNString(4));
            }
            System.out.println("---------------------------");
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
    }
}
