
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hfkra
 */
public class Apartado1 {
    
        //Mostrar y pedir información de la base de datos en general.
        //Por ejemplo, 4 primeras columnas de las 2 filas de la tabla vuelos.
    
    public static void main(String[] args){
        
        try {
            String urljdbc = "jdbc:oracle:thin:@localhost:1521:XE";
            Connection con = DriverManager.getConnection(urljdbc,"c##javier", "javier");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT COD_VUELO, HORA_SALIDA, DESTINO, PROCEDENCIA FROM VUELOS WHERE ROWNUM <= 2");
            while(rs.next()){
                System.out.println("-------------------------------");
                System.out.println("Código de vuelo: "+rs.getString(1)
                    +"\nHora de salida: "+rs.getString(2)+"H"
                    +"\nDestino: "+rs.getString(3)
                    +"\nProcedencia: "+rs.getString(4));
            }
            System.out.println("-------------------------------");
            
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
