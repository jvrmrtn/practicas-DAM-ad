
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hfkra
 */
public class Apartado3 {
    
        //Ver la información de los pasajeros de un vuelo, pasando el código de vuelo como parámetro.
    
    public static void main(String[] args){
        
        String codVuelo;
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce el código de vuelo: ");
        codVuelo = sc.nextLine();
        boolean codCorrecto = false;
        //Codigos de vuelo: IB-SP-4567, IB-BA-46DC, FR-DC-4667, AV-DC-347, SP-DC-438, AI-D7-347,
        //IB-D5-347, FR-DC7-247, AV-DC9-233, FR-DC2-269, IB-98779, AV-DC2-269, AV-DC2-269.
        
        try {
            String urljdbc = "jdbc:oracle:thin:@localhost:1521:XE";
            Connection con = DriverManager.getConnection(urljdbc, "c##javier", "javier");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM PASAJEROS WHERE COD_VUELO = '"+codVuelo+"'");
            
            while(rs.next()){
                if(rs.getString(2).equals(codVuelo)){
                    System.out.println("---------------------------");
                    System.out.println("Pasajero nº: "+rs.getInt(1)
                        +"\nCodigo de vuelo: "+rs.getString(2)
                        +"\nTipo de plaza: "+rs.getString(3)
                        +"\nFumador: "+rs.getNString(4));
                    codCorrecto = true;
                }
            }
            if(codCorrecto){
                System.out.println("---------------------------");
            }else{
                System.out.println("No se han encontrado vuelos con el código proporcionado.");
            }
            rs.close();
            st.close();
            con.close();
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}


