
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hfkra
 */
public class Apartado5 {
    
        //Borrar el vuelo que se metió anteriormente en el que se pasa por parámetro su número de vuelo.
    
    public static void main(String[] args){
    
        Scanner sc = new Scanner(System.in);
        String codVuelo = "";
        boolean confirm = false;
        
        System.out.println("Programa para borrar vuelos en la base de datos");
        System.out.println("--------------------------------------------------");
        System.out.print("Introduzca el Código de Vuelo: ");
        codVuelo = sc.nextLine();
        
        try {
            String urljdbc = "jdbc:oracle:thin:@localhost:1521:XE";
            Connection con = DriverManager.getConnection(urljdbc, "c##javier", "javier");
        
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT COD_VUELO FROM VUELOS");
            while(rs.next()){
                if(codVuelo.equals(rs.getString(1))){
                    confirm = true;
                }
            }
            
            String sql = "DELETE FROM VUELOS WHERE COD_VUELO = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, codVuelo);
            pst.executeUpdate();
            
            if(confirm){
                System.out.println("--------------------------------------------------");            
                System.out.println("Vuelo borrado.");
                System.out.println("--------------------------------------------------");
            }else{
                System.out.println("--------------------------------------------------");            
                System.out.println("El codigo de vuelo no aparece en la base de datos.");
                System.out.println("--------------------------------------------------");
            }
            
            pst.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
