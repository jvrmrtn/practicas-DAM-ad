
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hfkra
 */
public class Apartado4 {
    
        //Insertar un vuelo cuyos valores se pasan como parámetros.
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        String codVuelo, horaSalida, dest, proc; 
        int plaFum, plaNoFum,plaTur, plaPri;
        
        System.out.println("Programa para la introducción de vuelos en la base de datos");
        System.out.println("-----------------------------------------------------------");
        System.out.print("Introduzca el Código de Vuelo (FORMATO XX-XX-0000): ");
        codVuelo = sc.nextLine();
        System.out.print("Introduzca la fecha y hora de salida (FORMATO dd/mm/yy hh:mm): ");
        horaSalida = sc.nextLine();
        System.out.print("Introduzca el destino del vuelo: ");
        dest = sc.nextLine();
        System.out.print("Introduzca la procedencia del vuelo: ");
        proc = sc.nextLine();
        System.out.print("Introduzca el número de plazas de fumadores: ");
        plaFum = sc.nextInt();
        System.out.print("Introduzca el número de plazas de NO fumadores: ");
        plaNoFum = sc.nextInt();
        System.out.print("Introduzca el número de plazas de clase turista: ");
        plaTur = sc.nextInt();
        System.out.print("Introduzca el número de plazas de primera clase: ");
        plaPri = sc.nextInt();
        
        try {
            String urljdbc = "jdbc:oracle:thin:@localhost:1521:XE";
            Connection con = DriverManager.getConnection(urljdbc, "c##javier", "javier");
            PreparedStatement pst = con.prepareStatement("INSERT INTO VUELOS"
                +"(COD_VUELO, HORA_SALIDA, DESTINO, PROCEDENCIA, PLAZAS_FUMADOR, PLAZAS_NO_FUMADOR, PLAZAS_TURISTA, PLAZAS_PRIMERA)"
                + " VALUES (?,?,?,?,?,?,?,?)"
                +"");
            pst.setString(1, codVuelo);
            pst.setString(2, horaSalida);
            pst.setString(3, dest);
            pst.setString(4, proc);
            pst.setInt(5, plaFum);
            pst.setInt(6, plaNoFum);
            pst.setInt(7, plaTur);
            pst.setInt(8, plaPri);            
            pst.executeUpdate();
            
            System.out.println("-----------------------------------------------------------");            
            System.out.println("Vuelo creado con éxito.");
            System.out.println("-----------------------------------------------------------");
            pst.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
