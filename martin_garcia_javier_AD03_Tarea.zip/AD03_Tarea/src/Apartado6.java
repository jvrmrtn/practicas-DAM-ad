
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hfkra
 */
public class Apartado6 {
        
        //Modificar los vuelos de fumadores a no fumadores.
    
    public static void main(String[] args){
        
        String sql = "UPDATE VUELOS SET PLAZAS_NO_FUMADOR = ? WHERE COD_VUELO = ?";
        
        try {
            String urljdbc = "jdbc:oracle:thin:@localhost:1521:XE";
            Connection con = DriverManager.getConnection(urljdbc, "c##javier", "javier");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM VUELOS");
            PreparedStatement pst = con.prepareStatement(sql);
            while(rs.next()){
                pst.setInt(1, rs.getInt(5));
                pst.setString(2, rs.getString(1));
                pst.executeUpdate();
            }
            pst.close();
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
       
    }
}
